import React, { useEffect} from "react";
import Header  from "../components/Header";

interface AlbumProps {
    currentPage: string;
    headerLightBgActive: boolean;
    setCurrentPage: (value:string) => void;
    setHeaderLightBgActive: (value: boolean) => void;

}
const Albums: React.FC<AlbumProps> = ({
    currentPage,
    headerLightBgActive,
    setCurrentPage,
    setHeaderLightBgActive
}) => {
    useEffect(() => {
        setHeaderLightBgActive(true);
        setCurrentPage("albums");
    }, []);
    const albums = [
        { id: 1, title: "Midnight Dreams", artist: "Luna Wave", cover: "https://images.unsplash.com/photo-1507874457470-272b3c8d8ee2" },
        { id: 2, title: "Soul Vibrations", artist: "Soul Vibrations", cover:"https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3" },
        { id: 3, title: "Echoes of Tomorrow", artist: "Ava Nyx", cover: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4"},
    ];

    return (
        <div className="albums">
            <Header lightBgActive={headerLightBgActive} currentPage={currentPage} />
            <div className="albums-content" style={{ padding: "2rem"}}>
                <h1>Albums Released</h1>
                <p>Discover the latest music releases from our creative artist.</p>
                <div
                style={{
                    display: "grid",
                    gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
                    gap: "1.5rem",
                    marginTop: "2rem",
                }}
                >
                    {albums.map((album) =>(
                        <div
                          key={album.id}
                          style={{
                            border: "1px solid #ddd",
                            borderRadius: "10px",
                            overflow: "hidden",
                            boxShadow: "0 2px 6px rgba(0,0,0,0.1)",

                          }}
                          >
                            <img
                    src={album.cover}
                    alt={album.title}
                    style={{
                        width: "100%",
                        height: "250px",
                        objectFit: "cover",
                    }}
                   />

                    
                    
                   <div style={{ padding: "1rem"}}>
                     <h3>{album.title}</h3>
                     <p style={{ color: "#666"}}>by {album.artist}</p>
                   </div>
                   </div>
                   ))}
                </div>
            </div>
        </div>
    );
};

export default Albums;